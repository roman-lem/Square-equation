var searchData=
[
  ['this_20libruary_20is_20solving_20square_20and_20linear_20equations_8',['This libruary is solving square and linear equations',['../index.html',1,'']]],
  ['test_5fiszero_9',['Test_isZero',['../_solve_equations_8h.html#ace74290f5c4f9181360cf7530de636ea',1,'SolveEquations.h']]]
];
