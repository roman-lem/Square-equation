var searchData=
[
  ['this_20libruary_20is_20solving_20square_20and_20linear_20equations_19',['This libruary is solving square and linear equations',['../index.html',1,'']]]
];
