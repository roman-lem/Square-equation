var indexSectionsWithContent =
{
  0: "dilmst",
  1: "s",
  2: "ilmst",
  3: "i",
  4: "d",
  5: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Macros",
  5: "Pages"
};

